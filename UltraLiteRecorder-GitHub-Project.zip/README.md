# UltraLite Recorder (prototype)

Native Kotlin Android project intended to build in GitHub Actions without Android Studio.

## Current prototype scope
- Android MediaProjection consent prompt.
- Foreground recording service.
- H.264 MP4 screen recording, capped to 720p and configured for 30 FPS.
- Microphone is not requested or enabled.
- No ads, analytics, login, or network permissions.

## Important limitation
This first build is **video-only**. Internal/game audio is deliberately not claimed as implemented. Capturing playback audio on Android 10+ requires `AudioPlaybackCaptureConfiguration` + `AudioRecord`, an AAC encoder, and synchronized audio/video muxing; app/game playback capture policy can also block it. Add and test that pipeline as a separate phase before using this as a game-audio recorder.

## Build from phone using GitHub
1. Create a new GitHub repository named `UltraLiteRecorder`.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Android APK Build** (or push a commit to `main`).
5. Open the completed workflow run → **Artifacts** → download `UltraLiteRecorder-debug-apk`.
6. Extract the artifact ZIP on your phone and install `app-debug.apk`. You may need to allow installs from your browser/file manager.

## Output location
The prototype saves recordings under the app-specific Movies folder:
`Android/data/com.daksh.ultraliterecorder/files/Movies/UltraLiteRecorder/`

## Testing checklist
- Test permission prompt and start/stop.
- Check portrait and landscape capture.
- Test 5-minute recording and playback.
- Verify storage space and thermal behaviour.
- Do not assume low heat/zero lag: recording still consumes encoder, memory bandwidth and GPU resources.
